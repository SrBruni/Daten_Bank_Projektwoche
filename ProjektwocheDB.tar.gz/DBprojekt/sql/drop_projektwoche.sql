-- Miniwelt Projektwoche
-- Authoren Bruni, Zumpe
-- Datum: 15.04.24
-- Funktion: Löscht alle Tabellen aus der Datenbank 

DROP table angestellte CASCADE;
DROP table schuelerInnen CASCADE;
DROP table nimmt_teil CASCADE;
DROP table leitet CASCADE;
DROP table leitet_mit CASCADE;
DROP table projekt CASCADE;
DROP table findet_statt CASCADE;
DROP table raum_oder_ort CASCADE;

